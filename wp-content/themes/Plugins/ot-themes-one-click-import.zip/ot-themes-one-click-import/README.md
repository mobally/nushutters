# WBC907-Plugin-Example
Example plugin for Reduxframework extensions loading


Make sure to set option name in `wbc907-plugin-example.php` file

